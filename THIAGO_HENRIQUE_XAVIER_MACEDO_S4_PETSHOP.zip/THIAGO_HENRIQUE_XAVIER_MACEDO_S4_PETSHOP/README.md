# Sistema-Petshop
Este repositório contém o código-fonte da aplicação desenvolvida para o Pet Shop “Amigo Fiel”, com o objetivo de substituir os processos manuais de gestão através de planilhas. A aplicação foi criada para permitir o gerenciamento eficiente de produtos, clientes e vendas, automatizando cálculos e atualizando o estoque em tempo real.
